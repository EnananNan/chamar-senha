import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
 
export default function App() {
  const [senha, setSenha] = useState(null);
  const [tempoRestante, setTempoRestante] = useState(null);
 
  const senhas = [
    { tipo: 'Normal', tempo: 90 }, 
    { tipo: 'Prioritária', tempo: 45 }, 
    { tipo: 'Alta Prioridade', tempo: 30 }, 
  ];
 
  const [indiceSenha, setIndiceSenha] = useState(0);
 

  const chamarSenha = () => {
    if (indiceSenha < senhas.length) {
      const senhaAtual = senhas[indiceSenha];
      setSenha(senhaAtual.tipo);
      setTempoRestante(senhaAtual.tempo);
      setIndiceSenha(indiceSenha + 1); 
    }
  };
 
  // Função para gerenciar o tempo da senha chamada
  useEffect(() => {
    if (tempoRestante === null) return;
 
    const intervalo = setInterval(() => {
      setTempoRestante((prevTempo) => {
        if (prevTempo > 0) return prevTempo - 1;
        return prevTempo;
      });
    }, 1000);
 
    return () => clearInterval(intervalo); 
  }, [tempoRestante]);
 
  useEffect(() => {
    if (tempoRestante === 0 && indiceSenha < senhas.length) {
      chamarSenha();
    }
  }, [tempoRestante, indiceSenha]);
 
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Sistema de Chamada de Senhas</Text>
      {senha && <Text style={styles.senhaText}>Senha {senha} esta sendo chamada</Text>}
      {tempoRestante !== null && (
        <Text style={styles.tempoText}>
          Tempo restante: {tempoRestante}s
        </Text>
      )}
      <Button title="Chamar Senha" onPress={chamarSenha} />
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  titulo: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  senhaText: {
    fontSize: 18,
    color: 'green',
    marginBottom: 10,
  },
  tempoText: {
    fontSize: 16,
    color: 'red',
    marginBottom: 20,
  },
});